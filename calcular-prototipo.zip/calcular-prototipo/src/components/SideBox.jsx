import { useState } from "react";
import "./SideBox.css";

function SideBox() {
   
  // Estado para armazenar pontos, cálculo e resposta do jogador
  const [pontos, setPontos] = useState(0);
  const [desafio, setDesafio] = useState('');
  const [respostaUsuario, setRespostaUsuario] = useState('');
  const [resultadoCorreto, setResultadoCorreto] = useState(null);
  const [operacao, setOperacao] = useState('');

  // Função para gerar um cálculo aleatório
  const gerarDesafio = () => {
    // Gerar números aleatórios entre 1 e 20
    const num1 = Math.floor(Math.random() * 20) + 1;
    const num2 = Math.floor(Math.random() * 20) + 1;

    // Gerar uma operação aleatória entre adição, subtração, multiplicação e divisão
    const operacoes = ['+', '-', '*', '/'];
    const operacaoEscolhida = operacoes[Math.floor(Math.random() * operacoes.length)];

    // Gerar a expressão com base na operação
    let desafioCalculado;
    let resultado;

    
    switch (operacaoEscolhida) {
      case '+':
        desafioCalculado = `${num1} + ${num2}`;
        resultado = num1 + num2;
        break;
      case '-':
        desafioCalculado = `${num1} - ${num2}`;
        resultado = num1 - num2;
        break;
      case '*':
        desafioCalculado = `${num1} * ${num2}`;
        resultado = num1 * num2;
        break;
      case '/':
        desafioCalculado = `${num1} / ${num2}`;
        resultado = (num1 / num2).toFixed(2); // Resultado com duas casas decimais para divisão
        break;
      default:
        return;
        
      }

    // Definir o desafio e o resultado correto
    setDesafio(desafioCalculado);
    setResultadoCorreto(parseFloat(resultado));
    setOperacao(operacaoEscolhida);
  };

  // Função para validar a resposta do usuário
  const validarResposta = () => {
    if (parseFloat(respostaUsuario) === resultadoCorreto) {
      setPontos(pontos + 10); // Adiciona 10 pontos se a resposta estiver correta
    }
    setRespostaUsuario(''); // Limpar a resposta após a validação
  };

  // Função para iniciar um novo jogo
  const novoJogo = () => {
    setPontos(0); // Zera os pontos
    setRespostaUsuario(''); // Limpa a resposta do jogador
    setResultadoCorreto(null); // Limpa o resultado correto
    setDesafio(''); // Limpa o desafio
  };

  return (
      <div className="tela-roxa">
      
      <div className="header-topo">
       <h1> Você tem {pontos} pontos </h1>
      
      {/* Botão para sortear um novo desafio */}
      <button onClick={gerarDesafio}>Sortear Desafio</button>
      </div>

     <div className="container-desafio">
     
     <h3>Quanto é :</h3>
      {desafio && <p>{desafio}</p>}

      
      {/* Campo de resposta do usuário */}
      <h3>Sua Resposta :</h3>
      <input
        type="text"
        value={respostaUsuario}
        onChange={(e) => setRespostaUsuario(e.target.value)}
        />
      </div>

      <div className="botao-validar">
      {/* Botão para validar a resposta */}
      <button onClick={validarResposta}>Validar</button>
      </div>

      <div className="botao-jogo">
      {/* Botão para iniciar um novo jogo */}
      <button onClick={novoJogo}>Novo Jogo</button>
    </div>
  </div>
  );
}
  

  export default SideBox;
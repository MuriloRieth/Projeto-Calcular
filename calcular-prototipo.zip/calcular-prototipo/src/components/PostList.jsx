import Post from "./Post";
import "./PostList.css";

const imagemPostList ="public\calcular.jpg";
  
const quebraDeLinha = (texto) => {
  return texto.split('\n').map((parte, index) => (
    <span key={index}>
      {parte}
      <br />
    </span>
  ));
};

function PostList() {
  return (
    <div className="post-list">
      <Post
        
        imagem={imagemPostList}
        
        titulo={quebraDeLinha(`Para ser muito bom amanhã, é preciso 
          começar a praticar hoje`
        )}
        prof="Prof. Cleiton"
        data="24 Fev 25"
        hora="16:40"
        
        texto={quebraDeLinha(
          `São nos primeiros anos escolares que as crianças aprendem os fundamentos da 
          matemática, inclusive as quatro operações - soma, subtração, multiplicação e 
          divisão. Qualquer dificuldade que a criança tenha nessa fase se refletirá por toda 
          a sua vida escolar :( `
        )}
        
        texto2={quebraDeLinha(
          `Aqui você e seu filho irão encontrar exercícios relacionados ao conteúdo ensinado
          nos primeiros anos escolares e buscarão aperfeiçoar seu conhecimento nas 
          operações básicas;`
        )}
      />

      <Post
        titulo={quebraDeLinha(`Matemática: O Alicerce para o Sucesso 
          Escolar!`
        )}
        
        prof="Prof. Cleiton"
        data="24 Fev 25"
        hora="16:40"
        
        texto={quebraDeLinha(
          `Nos primeiros anos escolares, as crianças constroem a base do raciocínio lógico e 
          aprendem as quatro operações essenciais: adição, subtração, multiplicação e 
          divisão. 
          Dificuldades nessa fase podem afetar o desempenho escolar ao longo de toda a 
          jornada!
          Aqui, você encontra exercícios divertidos e educativos para ajudar seu filho a 
          dominar as operações básicas e desenvolver confiança na matemática.`
        )}
        
        texto3={quebraDeLinha(
          `Vamos juntos fortalecer essa base e transformar desafios em conquistas!
          #MatemáticaParaCrianças #EducaçãoMatemática #OperaçõesBásicas 
          #AprendizadoDivertido #FundamentosEscolares #MatemáticaFácil 
          #ConfiançaNosNúmeros`
        )}
      />
    </div>
  );
}

export default PostList; 
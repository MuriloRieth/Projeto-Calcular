import "./Header.css";

function Header() {
    const dateHeader = "07/06/2022"; 
    
    return (
        <header className="header">
            <img src="public\projeto.jpg" alt="" />
            <div className="header-subtitulo">Ferramentas de aprendizagem em cálculo</div>
            <div className="date-bar">{dateHeader}</div>
        </header>
    );
}

export default Header;   
import "./Post.css";

function Post({ imagem, titulo, prof, data, hora, texto, texto2, texto3 }) {
    return (
      <div className="post-container">
        {imagem && (
          <div className="post-imagem">
            <img src="public\calcular.jpg" alt="" />
          </div>
        )}
        <h2 className="post-titulo">{titulo}</h2>
        <div className="post-meta" >
          <span className="post-prof">{prof}</span>
          <span className="post-data">{data}</span>
          <span className="post-hora">{hora}</span>
        </div>
        <hr/>
        <p className="post-texto">{texto}</p>
        <br />
  
        <p className="post-texto">{texto2}</p>
        <p className="post-texto">{texto3}</p>
      </div>
    );
  }
  
  export default Post;
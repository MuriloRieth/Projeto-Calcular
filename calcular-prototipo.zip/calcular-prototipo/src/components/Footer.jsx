import "./Footer.css";

function Footer(){

    return (
        <footer className="footer">
          <p> Projeto_Calcular - React </p>
        </footer>
      );
    }

    export default Footer;
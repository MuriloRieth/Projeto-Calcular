import PostList from './components/PostList';
import Header from './components/Header';
import SideBox from './components/SideBox';
import Footer from './components/Footer';
import './App.css'

function App() {
  

  return (
    
    <div className="calcular">
      <Header />
      <section
          style={{display:"flex"}}>
      
            <PostList />
            <SideBox/>
          </section>  
    <Footer/>
    </div>

  )
}

export default App;